"use client";

import { useState } from "react";
import PokemonGrid from "@/components/pokemon-grid";
import { usePokemonList } from "@/lib/hooks/use-pokemon-list";
import { Button } from "@/components/ui/button";

const LIMIT = 20;

export default function PaginationView() {
  const [currentPage, setCurrentPage] = useState(1);
  const offset = (currentPage - 1) * LIMIT;

  const { data, isLoading, error, refetch } = usePokemonList(LIMIT, offset);

  const totalPages = data ? Math.ceil(data.count / LIMIT) : 0;

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-4">
        <p className="text-destructive text-lg font-semibold">
          Error loading Pokémon
        </p>
        <p className="text-muted-foreground">{error.message}</p>
        <Button
          onClick={() => refetch()}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PokemonGrid pokemon={data?.results || []} isLoading={isLoading} />

      <div className="flex items-center justify-center gap-2 flex-wrap">
        <Button
          onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
          disabled={currentPage === 1 || isLoading}
          variant="outline"
        >
          Previous
        </Button>

        <div className="flex gap-1 flex-wrap">
          {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
            let pageNum = currentPage - 2 + i;
            if (pageNum < 1) pageNum = 1;
            if (pageNum > totalPages) pageNum = totalPages;

            return (
              <Button
                key={`${pageNum}-${crypto.randomUUID()}`}
                onClick={() => setCurrentPage(pageNum)}
                variant={pageNum === currentPage ? "default" : "outline"}
                className={
                  pageNum === currentPage
                    ? "bg-primary text-primary-foreground"
                    : ""
                }
              >
                {pageNum}
              </Button>
            );
          })}
        </div>

        <Button
          onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage === totalPages || isLoading}
          variant="outline"
        >
          Next
        </Button>

        <span className="text-muted-foreground text-sm ml-4">
          Page {currentPage} of {totalPages}
        </span>
      </div>
    </div>
  );
}
