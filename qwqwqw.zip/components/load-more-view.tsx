"use client"

import { useState } from "react"
import { useInfiniteQuery } from "@tanstack/react-query"
import PokemonGrid from "@/components/pokemon-grid"
import { pokéAPIClient } from "@/lib/api-client"
import { Button } from "@/components/ui/button"

const LIMIT = 20

export default function LoadMoreView() {
  const [displayedPokemon, setDisplayedPokemon] = useState<any[]>([])

  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading, error } = useInfiniteQuery({
    queryKey: ["pokemon-infinite"],
    queryFn: ({ pageParam = 0 }) => pokéAPIClient.getPokemonList(LIMIT, pageParam),
    initialPageParam: 0,
    getNextPageParam: (lastPage) => {
      const nextOffset = lastPage.results.length + (lastPage.offset || 0)
      return nextOffset < lastPage.count ? nextOffset : undefined
    },
  })

  // Combine all fetched pages
  const allPokemon = data?.pages.flatMap((page) => page.results) || []

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-4">
        <p className="text-destructive text-lg font-semibold">Error loading Pokémon</p>
        <p className="text-muted-foreground">{error.message}</p>
        <Button
          onClick={() => {
            window.location.reload()
          }}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          Retry
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <PokemonGrid pokemon={allPokemon} isLoading={isLoading} />

      {hasNextPage && (
        <div className="flex justify-center">
          <Button
            onClick={() => fetchNextPage()}
            disabled={isFetchingNextPage || isLoading}
            className="bg-primary text-primary-foreground hover:bg-primary/90"
            size="lg"
          >
            {isFetchingNextPage ? "Loading..." : "Load More"}
          </Button>
        </div>
      )}

      {!hasNextPage && allPokemon.length > 0 && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">You've reached the end!</p>
        </div>
      )}
    </div>
  )
}
